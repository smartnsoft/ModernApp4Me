﻿Before starting the development of your app, make sur that you have specified the author and the date on the following files :
- Constants.cs
- LocalizedStrings.cs
- App.xaml.cs
- Services.cs
- MainView.xaml.cs