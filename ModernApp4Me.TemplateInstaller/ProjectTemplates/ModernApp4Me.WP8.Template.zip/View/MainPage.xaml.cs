﻿using System.Windows.Navigation;
using Microsoft.Phone.Controls;

namespace $safeprojectname$.View
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructeur
        public MainPage()
        {
            InitializeComponent();

            // Exemple de code pour la localisation d'ApplicationBar
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            
        }
    }
}